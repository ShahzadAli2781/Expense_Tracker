# Expense Tracker

A simple, beginner-friendly console-based Expense Tracker written in Python. This project is designed to demonstrate basic Python programming concepts such as variables, input/output, loops, conditionals, and mathematical operations. 

This is a perfect project for an introductory programming course or a basic internship submission.

## Features
- **Continuous Input:** Users can enter as many expenses as they want in a single session.
- **Dynamic Accumulation:** Automatically keeps track of the total amount spent as expenses are entered.
- **Graceful Exit:** Type `done` at any time to stop entering expenses.
- **Input Validation:** 
  - Prevents the entry of negative expenses.
  - Handles invalid text inputs without crashing the program.
- **Statistical Summary:** Once finished, it displays:
  - The total number of expenses entered.
  - The total amount spent.
  - The average expense value.

## Requirements
- Python 3.x

## How to Run
1. Ensure you have Python installed on your computer.
2. Open your terminal or command prompt.
3. Navigate to the folder containing the project file.
4. Run the following command:
   ```bash
   python expense_tracker.py
   ```

## Example Usage
```text
----------------------------------------
      WELCOME TO EXPENSE TRACKER
----------------------------------------
Type 'done' anytime to stop and see your summary.
----------------------------------------
Enter an expense amount (or 'done' to finish): 15.50
Added: $15.50 | Current Total: $15.50

Enter an expense amount (or 'done' to finish): 10
Added: $10.00 | Current Total: $25.50

Enter an expense amount (or 'done' to finish): -5
Error: Expense cannot be negative. Please enter a positive amount.

Enter an expense amount (or 'done' to finish): abc
Error: Invalid input! Please enter a valid number or 'done'.

Enter an expense amount (or 'done' to finish): 24.50
Added: $24.50 | Current Total: $50.00

Enter an expense amount (or 'done' to finish): done

========================================
          EXPENSE SUMMARY
========================================
Total Expenses Entered: 3
Total Amount Spent:     $50.00
Average Expense:        $16.67
========================================
Thank you for using the Expense Tracker. Goodbye!
========================================
```

## Developer Notes
This project avoids advanced programming concepts (like OOP, databases, APIs, GUI, or external libraries) to keep the logic clear, readable, and highly accessible for beginners.
