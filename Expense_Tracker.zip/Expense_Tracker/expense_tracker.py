import tkinter as tk
from tkinter import ttk, messagebox

class ExpenseTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Expense Tracker")
        self.root.geometry("400x550")
        self.root.configure(bg="#f8f9fa")
        
        # Core variables (same logic as the console version)
        self.total_amount = 0.0
        self.expense_count = 0
        
        self.setup_ui()
        
    def setup_ui(self):
        # Configure styles for a clean, professional look
        style = ttk.Style()
        # Use 'clam' theme if available for a more modern flat look
        if 'clam' in style.theme_names():
            style.theme_use('clam')
            
        style.configure('TFrame', background='#f8f9fa')
        style.configure('TLabel', background='#f8f9fa', font=('Segoe UI', 11))
        style.configure('Header.TLabel', font=('Segoe UI', 20, 'bold'), foreground='#2b2d42')
        style.configure('Stat.TLabel', font=('Segoe UI', 13, 'bold'), foreground='#d90429')
        style.configure('TButton', font=('Segoe UI', 10, 'bold'), background='#8d99ae', foreground='white')
        style.map('TButton', background=[('active', '#2b2d42')])

        # Main padding frame
        main_frame = ttk.Frame(self.root, padding="25")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title Header
        header = ttk.Label(main_frame, text="Expense Tracker", style='Header.TLabel')
        header.pack(pady=(0, 20))
        
        # Input Area Frame
        input_frame = ttk.Frame(main_frame)
        input_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(input_frame, text="Amount ($):").pack(side=tk.LEFT, padx=(0, 10))
        
        self.amount_var = tk.StringVar()
        self.amount_entry = ttk.Entry(input_frame, textvariable=self.amount_var, font=('Segoe UI', 12), width=12)
        self.amount_entry.pack(side=tk.LEFT, padx=(0, 10))
        # Allow pressing 'Enter' key to add expense
        self.amount_entry.bind('<Return>', lambda event: self.add_expense())
        
        add_btn = ttk.Button(input_frame, text="Add", command=self.add_expense)
        add_btn.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Expense History Area
        history_frame = ttk.Frame(main_frame)
        history_frame.pack(fill=tk.BOTH, expand=True, pady=15)
        
        ttk.Label(history_frame, text="Recent Expenses:", font=('Segoe UI', 10, 'bold')).pack(anchor=tk.W, pady=(0, 5))
        
        # Scrollbar for the listbox
        scrollbar = ttk.Scrollbar(history_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.history_list = tk.Listbox(history_frame, yscrollcommand=scrollbar.set, font=('Consolas', 12), 
                                       bg='#ffffff', fg='#2b2d42', relief=tk.FLAT, highlightthickness=1, highlightcolor='#cccccc')
        self.history_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.history_list.yview)
        
        # Visual separator
        ttk.Separator(main_frame, orient='horizontal').pack(fill=tk.X, pady=15)
        
        # Summary Statistics Area
        summary_frame = ttk.Frame(main_frame)
        summary_frame.pack(fill=tk.X)
        
        # Grid layout for summary labels
        ttk.Label(summary_frame, text="Total Expenses:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.lbl_count = ttk.Label(summary_frame, text="0", style='Stat.TLabel', foreground='#2b2d42')
        self.lbl_count.grid(row=0, column=1, sticky=tk.E, pady=5)
        
        ttk.Label(summary_frame, text="Total Spent:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.lbl_total = ttk.Label(summary_frame, text="$0.00", style='Stat.TLabel')
        self.lbl_total.grid(row=1, column=1, sticky=tk.E, pady=5)
        
        ttk.Label(summary_frame, text="Average Expense:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.lbl_avg = ttk.Label(summary_frame, text="$0.00", style='Stat.TLabel', foreground='#2b2d42')
        self.lbl_avg.grid(row=2, column=1, sticky=tk.E, pady=5)
        
        # Push values to the right side of the window
        summary_frame.columnconfigure(1, weight=1)
        
        # Set focus to entry box on startup
        self.amount_entry.focus()

    def add_expense(self):
        user_input = self.amount_var.get().strip()
        
        # Empty input validation
        if not user_input:
            return
            
        try:
            # Convert input to float
            expense = float(user_input)
            
            # Prevent negative expenses
            if expense < 0:
                messagebox.showerror("Error", "Expense cannot be negative.")
                return
                
            # Accumulator logic
            self.total_amount = self.total_amount + expense
            self.expense_count = self.expense_count + 1
            
            # Update the listbox history
            self.history_list.insert(tk.END, f"  + ${expense:.2f}")
            self.history_list.yview(tk.END) # Scroll to bottom
            
            # Update the bottom summary
            self.update_summary()
            
            # Clear the input field for the next entry
            self.amount_var.set("")
            
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid number. Letters are not allowed.")

    def update_summary(self):
        # Update the labels with the new calculations
        self.lbl_count.config(text=f"{self.expense_count}")
        self.lbl_total.config(text=f"${self.total_amount:.2f}")
        
        # Calculate average safely
        if self.expense_count > 0:
            average = self.total_amount / self.expense_count
            self.lbl_avg.config(text=f"${average:.2f}")

# Application Entry Point
if __name__ == "__main__":
    root = tk.Tk()
    app = ExpenseTrackerApp(root)
    root.mainloop()
